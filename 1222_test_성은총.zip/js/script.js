$(function () {

    var current = 0;
    var pic = 0; // 현재 보이는 사진
    var setCelaer;


    //  헤더 메뉴 버튼
    $(document).ready(function () {
        $(".sub").show();
        $(".top_nav > ul > li").hover(
            function () {
                $(this).find(".sub").stop().css({ opacity: "0" }).animate({ opacity: "1" }, 1000);
            },
            function () {
                $(this).find(".sub").stop().css({ opacity: "1" }).animate({ opacity: "0" }, 1000);
            }
        );




        // on 활성화 및 비활성화
        $("#btns > li").eq(0).addClass("on");

        $("#btns > li").click(function () {
            var i = $(this).index();

            $("#btns > li").removeClass("on");
            $(this).addClass("on");

            move(i);
            console.log(i); // 클릭한 값이 잘 들어오는지 확인
        });


        // left 버튼

        $(".left").click(function () {

            var n = current + 1;
            if (n == 4) {
                n = 0;
            }
            $("#btns > li").removeClass("on");
            $("#btns > li").eq(n).addClass("on");

            move(n);

        });

        //right 버튼

        $(".right").click(function () {

            var n = current + 1;
            if (n == 4) {
                n = 0;
            }
            $("#btns > li").removeClass("on");
            $("#btns > li").eq(n).addClass("on");

            move2(n);

        });

        // 사진 넘기기

        $(".con_btns > li").eq(0).addClass("on");


        $(".con_btns > li").click(function (e) {


            var n = $(this).index();
            console.log(n);
            $(".con_btns > li").removeClass("on");
            $(this).addClass("on");
            slider_menu(n);

        });







        // 자동실행 제어
        $("#main_img").on({

            mouseover: function () {
                clearInterval(setCelaer);;
            },
            mouseout: function () {
                time();
            }
        });



        time();

        //     자동실행
        function time() {
            setCelaer = setInterval(function () {

                var n = current + 1;
                if (n == 4) {
                    n = 0;
                }

                $("#btns > li").removeClass("on");
                $("#btns > li").eq(n).addClass("on");

                move(n);

            }, 3000);
        }

        //오른쪽 퀵메뉴
        var box = $('#all > .box');

        $('#q_mn li').click(function () {
            var nn = $(this).index(); //버튼의 번호를 찾는거
            //console.log(nn);
            var tt = box.eq(nn); //버튼번호와 동일 box
            var tg = tt.offset().top; //위치를 이동할때 기준이 될 box 기준점을 설정
            $('html,body').stop().animate({ scrollTop: tg });
        });

        $(window).scroll(function () {
            var sct = $(window).scrollTop() + 200;
            $('#q_mn').stop().animate({ top: sct + "px" }, 500);
        });



        // 애니메이션 함수
        function move(n) {
            if (current == n) {   // 같으면 변환 x
                return;
            }

            var Stop_move = $("#view ul li").eq(current);
            var Next_move = $("#view ul li").eq(n);

            Stop_move.css({ left: "0%" }).animate({ left: "-100%" });
            Next_move.css({ left: "100%" }).animate({ left: "0%" });
            current = n;
        }


        function move2(n) {
            if (current == n) {   // 같으면 변환 x
                return;
            }

            var Stop_move = $("#view ul li").eq(current);
            var Next_move = $("#view ul li").eq(n);

            Stop_move.css({ left: "0%" }).animate({ left: "100%" });
            Next_move.css({ left: "-100%" }).animate({ left: "0%" });
            current = n;
        }


        // 사진 넘기기 애니메이션
        function slider_menu(n) {
            var num = n * (-360) + "px";
            pic = n;

            $(".con_box > ul").animate({ left: num }, 1000);

        }










    }); // end of ready


}); // end of function